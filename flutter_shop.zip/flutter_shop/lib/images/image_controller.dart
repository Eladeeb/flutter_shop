import 'base_image.dart';
class ImageController{
  BaseImage baseImage ;

  ImageController(this.baseImage);
  static List<BaseImage> toImages(List<Map<String,dynamic>> jsonObjects){

  }


}