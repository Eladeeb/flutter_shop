import 'user.dart';
class ShopOwner extends User{
  ShopOwner(String id, String firstName, String lastName, String email, String phone, String gender)
      : super(id, firstName, lastName, email, phone, gender);

}