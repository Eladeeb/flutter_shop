import 'package:flutter_shop/cart/base_cart_item.dart';

class BaseCartItemController{
  BaseCartItem baseCartItem ;

  BaseCartItemController(this.baseCartItem);
  static List<BaseCartItem> toBaseCartItems(List<Map<String,dynamic>> jsonObjects){

  }


}